---
title: "Buy me a coffee"
permalink: "/buy-me-a-coffee.html"
---

Hi! I am Sal, web designer & developer at WowThemes.net. The free items I create are my side projects and **Mundana for Jekyll** is one of them. You can find **all the work I release for free [here](https://www.wowthemes.net/category/free-themes-templates/)**. 

You have my permission to use the free items I develop in your personal, commercial or client projects. If you'd like to reward my work, I would be honored and I could dedicate more time maintaining the free projects. 

Thank you so much!

<a class="btn btn-danger" href="https://www.wowthemes.net/donate/">Buy me a coffee</a>
